"use strict";exports.id=746,exports.ids=[746],exports.modules={2746:(_,e,s)=>{s.d(e,{getDefaultRoleAssumerWithWebIdentity:()=>t.I$});var t=s(4245)}};
